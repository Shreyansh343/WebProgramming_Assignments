import React from "react";
import HelloReactWithoutJSX from "./components/HelloReactWithoutJSX";
import HelloReactWithJSX from "./components/HelloReactWithJSX";
import FruitsList from "./components/FruitsList";
import StyledMessage from "./components/StyledMessage";
import SumOfSquares from "./components/SumOfSquares";
import Greeting from "./components/Greeting";
import CurrentDay from "./components/CurrentDay";
import PrimeChecker from "./components/PrimeChecker";
import TemperatureConverter from "./components/TemperatureConverter";
import ReverseString from "./components/ReverseString";
import RandomNumber from "./components/RandomNumber";
import LeapYearChecker from "./components/LeapYearChecker";
import UserGreeting from "./components/UserGreeting";
import MessageVariable from "./components/MessageVariable";

const App = () => {
  return (
    <div>
      
      <HelloReactWithoutJSX />
      <HelloReactWithJSX />
      <MessageVariable />
      <FruitsList />
      <StyledMessage />
      <SumOfSquares num1={3} num2={4} />
      <Greeting isMorning={true} />
      <CurrentDay />
      <PrimeChecker number={7} />
      <TemperatureConverter />
      <ReverseString text="React" />
      <RandomNumber />
      <LeapYearChecker year={2024} />
      <UserGreeting firstName="Aditya Narayan " lastName="Bhandari" />
    </div>
  );
};

export default App;
