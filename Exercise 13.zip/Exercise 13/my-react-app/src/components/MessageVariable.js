import React from "react";

const MessageVariable = () => {
  const message = "Hello from a variable!";
  return <h1>{message}</h1>;
};

export default MessageVariable;
