import React from "react";

const SumOfSquares = () => {
  const a = 3, b = 4;
  const sum = a * a + b * b;

  return <p>The sum of squares of {a} and {b} is: {sum}</p>;
};

export default SumOfSquares;
