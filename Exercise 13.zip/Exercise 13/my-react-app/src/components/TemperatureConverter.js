import React, { useState } from "react";

const TemperatureConverter = () => {
  const [celsius, setCelsius] = useState("");
  const [fahrenheit, setFahrenheit] = useState("");

  const convertToFahrenheit = () => {
    setFahrenheit((celsius * 9) / 5 + 32);
  };

  const convertToCelsius = () => {
    setCelsius(((fahrenheit - 32) * 5) / 9);
  };

  return (
    <div>
      <input type="number" value={celsius} onChange={(e) => setCelsius(e.target.value)} placeholder="Celsius" />
      <button onClick={convertToFahrenheit}>Convert to Fahrenheit</button>
      <p>{fahrenheit && `${fahrenheit}°F`}</p>

      <input type="number" value={fahrenheit} onChange={(e) => setFahrenheit(e.target.value)} placeholder="Fahrenheit" />
      <button onClick={convertToCelsius}>Convert to Celsius</button>
      <p>{celsius && `${celsius}°C`}</p>
    </div>
  );
};

export default TemperatureConverter;
