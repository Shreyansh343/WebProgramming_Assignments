import React from "react";

const HelloReactWithoutJSX = () => {
  return React.createElement("h1", null, "Hello, React!");
};

export default HelloReactWithoutJSX;
