import React from "react";

const HelloReactWithJSX = () => {
  return <h1>Hello, React!</h1>;
};

export default HelloReactWithJSX;
