import React from "react";

const StyledMessage = () => {
  const style = { color: "blue", fontSize: "20px", fontWeight: "bold" };
  return <p style={style}>This is a styled message!</p>;
};

export default StyledMessage;
